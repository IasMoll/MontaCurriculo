package com.example.montacurriculo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import com.example.montacurriculo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val appBarConfiguration: AppBarConfiguration? = null
    private var binding: ActivityMainBinding? = null
    var buttonCadastrar: Button? = null // Declaração da variável

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        // Inicialização da variável buttonCadastrar, encontrando o botão pelo ID
        buttonCadastrar =
            findViewById<Button>(R.id.buttonCadastrarTelaInicial) // Substitua pelo ID REAL do seu botão

        // Definição do OnClickListener para o botão "Cadastrar"
        buttonCadastrar.setOnClickListener(View.OnClickListener { // Cria um Intent para iniciar a CadastroActivity
            val intent = Intent(
                this@MainActivity,
                CadastroActivity::class.java
            )
            startActivity(intent)
        })
    } // ... (seu código existente para onCreateOptionsMenu, onOptionsItemSelected, onSupportNavigateUp) ...
}